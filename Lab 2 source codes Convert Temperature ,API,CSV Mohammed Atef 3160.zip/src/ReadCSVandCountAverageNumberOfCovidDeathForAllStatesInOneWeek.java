import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadCSVandCountAverageNumberOfCovidDeathForAllStatesInOneWeek{

    public static final String delimiter = ",";

    public static void read(String csvFile) {
        try {
            File file = new File(csvFile);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            String line = "";
            int sum = 0 ;

            String[] tempArr = new String[0];



            while ((line = br.readLine()) != null) {

                tempArr = line.split(delimiter);

                for(int i = 2 ; i < tempArr.length ; i++) {

                   sum = sum + Integer.parseInt(tempArr[i]);
                }

            }
            br.close();
            System.out.println("Total count of how many times the songs were listened to  = " + sum);
            System.out.println("The average number of all songs that people listened to by all unique artists is : " + (sum/tempArr.length - 1));

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }

    public static void main(String[] args) {
        // csv file to read
        String csvFile = "/Users/za/Desktop/inputfile.csv";
        ReadCSVandCountAverageNumberOfCovidDeathForAllStatesInOneWeek.read(csvFile);
    }

}

