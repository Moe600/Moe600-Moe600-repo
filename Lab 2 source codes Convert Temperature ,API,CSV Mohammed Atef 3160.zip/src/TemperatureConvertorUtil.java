import java.util.Scanner;

public class TemperatureConvertorUtil {


        public static void main(String[] args) {
            Scanner scan = new Scanner(System.in);

            System.out.println("Enter 1  to convert from  Celsus to Farenheit");
            System.out.println("Enter 2  to convert from  Fahrenheit to Celsius");
            int choice = scan.nextInt();
            double temperature = 0.0;
            double converted = 0.0;


            if (choice==1) {


                System.out.println("Enter the temperature in Fahrenheit");
                temperature = scan.nextDouble();
                converted = ConvertFromFahrenheitToCelsus(temperature);
                System.out.println("Temperature in Celcius = " + converted);
            }

            else if (choice == 2){


                System.out.println("Enter the temperature in Celsus");
                temperature = scan.nextDouble();
                converted = ConvertFromCelsusToFahrenheit(temperature);
                System.out.println("Temperature in Fahrenheit = " + converted);



            }

            else
                System.out.println("Wrong Input, Try again!");


        }


        public static double ConvertFromFahrenheitToCelsus(double temperature){ return 5/9.0*(temperature-32); }
        public static double ConvertFromCelsusToFahrenheit(double temperature){ return 5/9.0*(temperature+32); }

}
